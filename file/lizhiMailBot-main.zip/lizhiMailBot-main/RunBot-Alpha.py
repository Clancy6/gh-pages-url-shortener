import yagmail
import json
import requests
#requests.adapters.DEFAULT_RETRIES = 8 # 增加重连次数
#s = requests.session()
#s.keep_alive = False # 关闭多余连接
import re
import random
import os
import time
import datetime
#now = datetime.datetime.now()
#nTime = now.strftime("%Y-%m-%d %H:%M:%S")
import ssl
ssl._create_default_https_context = ssl._create_unverified_context#解决不受信任SSL证书问题
import datetime
import sys
import urllib3
urllib3.disable_warnings()#隐藏不受信任的CA证书警告

def btw(str_,a,b,):
    re1=str(a+r'(.*?)'+b)
    reResult = re.findall(re1, str_)
    try:
        return reResult[0]
    except Exception:
        return('0')

def webget(f):
    headers={
        'User-Agent':"Mozilla/5.0 (Linux; Android 8.1.0; iKunOS) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36",
    }
    res = requests.get(str(f), verify=False)#取消网站CA证书验证
    #res = requests.get(str(f), headers=headers)
    res.encoding = 'utf-8'
    return(res.text)

def fread(f):#逐行读取文件
    with open(f, encoding='utf-8') as file_obj:
        contents = file_obj.read()
    return(contents.split("\n"))

yag = yagmail.SMTP( user="【你的邮箱】", password="【邮箱Token】", host="【邮箱服务器(类似mail.gmx.com)】")#登陆邮箱

toAddr = fread("toAddr.txt")#收件人列表

# ImgUrl移到toArddr的for循环里，优化随机图API.

data = webget("https://international.v1.hitokoto.cn/?encode=json&charset=utf-8&c=i")#一言API
print(data)
datas = json.loads(data)
print(str(datas))
if(datas["id"]!=""):
    ZHs = str(datas["hitokoto"])
    title = str(datas["from"])
    writer = str(datas["from_who"])
    #Daily_img = str(datas["data"]["pic"])
else:#Debug
    toAddr = ["【你的邮箱】"]#管理员邮箱
    subject = "lizhiMailBot Runner Failed!"
    contents = ["Hitokot API get failed.","Details:",str(datas)]
    yag.send(toAddr, subject, contents)
    exit()

#toAddr = [""]
print(str(toAddr))
#for To in toAddr:
for i in range(0,len(toAddr)-1):#解决GitHub上的文件读取后文件末尾多出一个“\n”的问题
    #调用https://github.com/Clancy6/PixivDailyPull仓库，之前设置了脚本，每天抓取排行榜上的pid（Thinks for ：https://github.com/No5972/pixiv-github-action）.
    imgList = webget("https://github.com/Clancy6/PixivDailyPull/raw/runner/pid.data")
    imgList = imgList.split("\n")
    imgUrl = random.choice(imgList)
    print(imgUrl)
    imgUrl2 = "https://xn--kiv39c36evrb.eu.org/api/pixiv/pixiv.php?pid="+imgUrl#有人抱怨cf的cdn打不开...（shit移动）
    imgUrl = "https://xn--kiv39c36evrb.eu.org/api/pixiv/pixiv.php?pid="+imgUrl#Pixiv Pid API，托管于46云虚拟主机.
    
    print(str(i))
    To = toAddr[i]
    if(To == ''):
        continue
    elif((not '@' in To)or(To[0]=="#")):#校验注释行
        continue
    else : #校验邮箱
        print(To)
        now = datetime.datetime.now()
        #subject = "There is a lizhi-mail for you."
        subject = ZHs
        contents = ["今天你荔枝了吗？", "<center>"+now.strftime("%Y-%m-%d")+"</center>","<hr/>"+ZHs, "<div align=\"right\"><p>《"+title+"》---"+writer+"</p></div>", '<br/><a href="'+imgUrl2+'"><center><img src='+imgUrl+' width="350" alt="如果图片不显示点我"></a></center>']
        #contents = ["今天你荔枝了吗？", "<center>"+now.strftime("%Y-%m-%d")+"</center>","<hr/>"+ZHs, "<div align=\"right\"><p>《"+title+"》---"+writer+"</p></div>", '<br/><a href="'+imgUrl2+'"><center><img src='+imgUrl2+' width="350" alt="如果图片不显示点我"></a></center>']#都说移动用户cf打不开，没想到是真的...
        yag.send(To, subject, contents)
        print("Test.")
        print("[",To,"]: Succeeded.")
    time.sleep(15)#api速率限制
